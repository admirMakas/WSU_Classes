function f=hannwin(n)
%HANNWIN Calls the function VONHANN.
%
% See also BLACKWIN, BOXWIN, EXPWIN, HAMMWIN, and TRIWIN.

%   Copyright (c) 1994 by Joseph C. Slater

f=vonhann(n);
