# Vibration-Testing-Matlab
Vibration Testing code affiliated with the in-progress manuscript Vibration Testing with Modal Analysis and Health Monitoring- Matlab version

A demonstration of many of the features can be access by running the
script `code:`vtdem`
